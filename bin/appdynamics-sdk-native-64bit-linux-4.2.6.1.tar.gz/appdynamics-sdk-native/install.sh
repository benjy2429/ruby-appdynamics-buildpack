#!/bin/sh
#
#
# Copyright 2014 AppDynamics.
# All rights reserved.
#
#
# Install script for AppDynamics Native SDK agent
#
usage() {
cat << EOF
  Usage: `basename $0`
  Options:
    -h,--help                     Show Help
    --with-selinux                Turn on SELinux features, including installation of the policy for the Webserver agent.
                                  This will temporarily disable SELinux for the duration of the installation.
    --ignore-selinux              Try installing even if SELinux might cause errors
    --with-selinux-module-path    If a selinux module has been copied to a different location
    --ignore-permissions          Ignores lack of write permissions on log and read permissions on the sdk folder
EOF
}

agentVersionId="4.2.6.1GA.13552.b79fa68647c46b26002db7f69c0a7c2ba1e729b7"
canonicalNameOfThisFile=`readlink -f "$0"`
containingDir=`dirname "$canonicalNameOfThisFile"`
withSELinux="false"
ignoreSELinux="false"
withSELinuxModulePath="${containingDir}/WebServerAgent/Apache/*"
ignoreFilePermissions="false"
ok=1
optspec=":h-:"

while getopts "$optspec" optchar; do
    case "${optchar}" in
        -)
            case "${OPTARG}" in
                help)
                    usage
                    exit 1
                    ;;
                with-selinux)
                    withSELinux="true"
                    ;;
                ignore-selinux)
                    ignoreSELinux="true"
                    ;;
                with-selinux-module-path=*)
                    withSELinuxModulePath=${OPTARG#*=}
                    ;;
                ignore-permissions)
                    ignoreFilePermissions="true"
                    ;;
                *)
                    ok=0
                    echo "Invalid option: '--${OPTARG}'" >&2
                    ;;
            esac
            ;;
        h)
             usage
             exit 1
             ;;
    esac
done
if [ "$ok" != 1 ]; then
    usage
    rm -f ${install_log}
    exit 1
fi
################################################################################
# Define functions
################################################################################

log() {
    echo "$@" >> ${install_log}
    if [ -z "${APPD_AUTO_MODE}" ]; then
        echo "$@"
    fi
}

log_error() {
    echo "[Error] $@" >> ${install_log}
    echo "[Error] $@" >&2
}

fatal_error() {
    log_error $1
    cat >&2 <<EOF

AppDynamics Native SDK Agent installation has failed. Please check $install_log for
possible causes. Please also attach it when filing a bug report.
EOF

    exit 1
}

escapeForSedReplacement() {
    local __resultVarName str __result
    __resultVarName="$1"
    str="$2"
    __result=$(echo "$str" | sed 's/[/&]/\\&/g')
    eval $__resultVarName=\'$__result\'
}

checkPathIsAccessible() {
    local __resultVarName currentPath findResult __result
    __resultVarName="$1"
    currentPath="$2"
    __result=""
    while [ "${currentPath}" != "/" ] ; do
        findResult=$(find "${currentPath}" -maxdepth 0 -perm -0005 2>/dev/null)
        if [ -z "${findResult}" ] ; then
            __result="${currentPath}"
            break
        fi
        currentPath=$(dirname "${currentPath}")
    done
    eval $__resultVarName="$__result"
}

if [ -z "${APPD_LOCATION}" ]; then
    APPD_LOCATION=$containingDir
    APPD_PACKAGE=0
else
    APPD_PACKAGE=1
fi

datestamp=`date +%Y_%m_%d_%H_%M_%S 2>/dev/null`
install_log=/tmp/appd_install_${datestamp}.log
rm -f $install_log > /dev/null 2>&1
cat > $install_log <<EOF
AppDynamics Native SDK agent installation log
Version: ${agentVersionId}
Date: `date 2>/dev/null`

Hostname: `hostname`
Location: ${APPD_LOCATION}
System: `uname -a 2>/dev/null`
User: `id`
Environment:
################################################################################
`env | sort`
################################################################################
EOF

echo "Install script for AppDynamics Native SDK Agent ${agentVersionId}"

## Installed files locations
log4cxxFile="${containingDir}/conf/appdynamics_sdk_log4cxx.xml"
ldconf="/etc/ld.so.conf.d/appdynamics_sdk_native.conf"

rootDirCheck=
checkPathIsAccessible rootDirCheck "${containingDir}"
if [ -n "${rootDirCheck}" ] ; then
    if [ "${ignoreFilePermissions}" = "true" ] ; then
        log "Native SDK directory '${containingDir}' is not readable by all users"
    else
        log_error "Native SDK directory '${containingDir}' is not readable by all users"
        fatal_error "Change the permissions of '${rootDirCheck}' or specify --ignore-permissions"
    fi
fi

agentLogDir="${containingDir}/logs"
logsDirCheck=$(find "${agentLogDir}" -maxdepth 0 -perm -0003 2>/dev/null)
if [ -z "${logsDirCheck}" ] ; then
    if [ "${ignoreFilePermissions}" = "true" ] ; then
        log "Native SDK logs directory '${agentLogDir}' is not writable by all users"
    else
        log_error "Native SDK logs directory '${agentLogDir}' is not writable by all users"
        fatal_error "Change the permissions of '${agentLogDir}' or specify --ignore-permissions"
    fi
fi

# write log4cxx file
escapeForSedReplacement agentLogDir "${agentLogDir}"
log4cxxTemplate="${log4cxxFile}.template"
log4cxxTemplateOwner=$(stat "--format=%u" "${log4cxxTemplate}")
log4cxxTemplateGroup=$(stat "--format=%g" "${log4cxxTemplate}")
log "Writing '${log4cxxFile}'"
cat "${log4cxxTemplate}" | \
    sed -e "s/__agent_log_dir__/${agentLogDir}/g"    \
         > "${log4cxxFile}"
if [ $? -ne 0 ] ; then
    fatal_error "Unable to write '${log4cxxFile}'"
fi

# Do this only if we are running as root.
if [ -w "$ldconf" ]; then
    echo "${containingDir}/sdk_lib/lib" > "$ldconf"
    [ -x `which ldconfig` ] && ldconfig
fi

chown "${log4cxxTemplateOwner}" "${log4cxxFile}"
chgrp "${log4cxxTemplateGroup}" "${log4cxxFile}"
chmod a+r "${log4cxxFile}"

# get selinux permissions if needed
seboolPreviousValuesFile="${containingDir}/selinux/sebool-preinstall-values.txt"
getenforce=`which getenforce 2>/dev/null`
seboolDesiredValues="httpd_execmem=on"

restore_sebools_and_delete_file() {
    if [ -f "${seboolPreviousValuesFile}" ]; then
        cat "${seboolPreviousValuesFile}" | while read varEqualsValue; do
            if setsebool -P "${varEqualsValue}"; then
                log "Restored and persisted SELinux boolean ${varEqualsValue}"
            else
                log "Failed to restore and persist SELinux boolean ${varEqualsValue}"
            fi
        done
        rm "${seboolPreviousValuesFile}"
    fi
}

if [ "$withSELinux" = "true" ]; then
    [ `uname` != "Linux" ] && fatal_error "The '--with-selinux' flag is not compatible with this operating system."
    [ ! -f "$getenforce" ] && fatal_error "The '--with-selinux' flag is specified but SELinux commands not found."
    [ "$EUID" -ne 0 ] && log "Trying to change SELinux settings without root permissions, trying but it might not work"

    appdWebServerConfigSELinuxContext=httpd_config_t
    appdWebServerModuleSELinuxContext=httpd_exec_t
    logDirSELinuxTypeContext=httpd_log_t
    proxyDirSELinuxTypeContext=httpd_var_run_t
    selinuxPolicy=generic
    fcontextFileType=--

    if [ -r /etc/redhat-release ]; then
        case `cat /etc/redhat-release` in
            CentOS\ release\ 5*)
                log "CentOS 5.x detected."
                ;;

            Derived\ from\ Red\ Hat\ Enterprise\ Linux\ 7*)
                log "Red Hat 7 detected."
                ;;

            CentOS\ release\ 6*)
                log "CentOS 6.x detected."
                ;;

            CentOS\ Linux\ release\ 7*)
                log "CentOS 7.x detected."
                fcontextFileType=f
                ;;

            Red\ Hat\ Enterprise\ Linux\ Server\ release\ 6*)
                log "RHEL 6.x detected."
                ;;

            Red\ Hat\ Enterprise\ Linux\ Server\ release\ 7*)
                log "RHEL 7.x detected."
                fcontextFileType=f
                ;;

            *)
                unset selinuxPolicy
                ;;
        esac
    elif which lsb_release >/dev/null 2>&1; then
        case `lsb_release -sir` in
            CentOS\ 5*)
                log "CentOS 5.x detected."
                ;;

            CentOS\ 6*)
                log "CentOS 6.x detected."
                ;;

            CentOS\ 7*)
                log "CentOS 7.x detected."
                fcontextFileType=f
                ;;

            RedHatEnterpriseServer\ 6*)
                log "RHEL 6.x detected."
                ;;

            RedHatEnterpriseServer\ 7*)
                log "RHEL 7.x detected."
                fcontextFileType=f
                ;;

            *)
                unset selinuxPolicy
                ;;
        esac
    else
        fatal_error "Don't know how to determine Linux distribution; only CentOS 5, 6, and 7 and RHEL 6 and 7 are compatible with the '--with-selinux' flag."
    fi

    [ -z "$selinuxPolicy" ] && fatal_error "Only CentOS 5, 6, and 7 and RHEL 6 and 7 are compatible with the '--with-selinux' flag."
fi

if [ -f "${getenforce}" -a "$ignoreSELinux" != "true" ]; then
    selStatus=`$getenforce`
    if [ "$selStatus" = "Enforcing" ]; then
        [ "$withSELinux" != "true" ] && fatal_error "SELinux is in enforcing mode but '--with-selinux' not specified; aborting."
        which semanage >/dev/null 2>&1 || fatal_error "'--with-selinux' specified but 'semanage' utility not installed; please remedy and try again."

        log "Temporarily setting SELinux enforcement mode to Permissive before installing."
        setenforce Permissive || fatal_error "Failed to set SELinux enforcement mode to Permissive."
        trap "log 'Re-enabling SELinux.'; setenforce $selStatus" 0 SIGINT SIGTERM SIGQUIT

        restore_sebools_and_delete_file

        for varEqualsValue in ${seboolDesiredValues}; do
            seboolVar="${varEqualsValue%=*}"
            desiredValue="${varEqualsValue##*=}"
            currentValue=`getsebool ${seboolVar} 2>/dev/null | awk '{print $3}'`
            [ -z "${currentValue}" ] && fatal_error "Failed to get value of SELinux boolean ${seboolVar}"
            if [ "${currentValue}" != "${desiredValue}" ]; then
                setsebool -P "${varEqualsValue}" || fatal_error "Failed to set SELinux boolean ${varEqualsValue}"
                log "Set and persisted SELinux boolean ${varEqualsValue}"
                echo "${seboolVar}=${currentValue}" >> "${seboolPreviousValuesFile}"
            fi
        done
    fi
fi

if [ "$withSELinux" = "true" ]; then
    # SELinux steps should come last.

    semanage fcontext -a -f "${fcontextFileType}" --type "${appdWebServerConfigSELinuxContext}" "${containingDir}/conf/.+" || fatal_error "Failed to set SELinux type context on AppDynamics config files"
    semanage fcontext -a -f "${fcontextFileType}" --type "${appdWebServerModuleSELinuxContext}" "${containingDir}/sdk_lib/lib/.+" || fatal_error "Failed to set SELinux type context on AppDynamics SDK module  s"
    semanage fcontext -a -f "${fcontextFileType}" --type "${appdWebServerModuleSELinuxContext}" "${withSELinuxModulePath}/.+" || log_error "Failed to set SELinux type context on AppDynamics WebServer modules because this is possibly a SDK version. Continuing"

    restorecon -R -v ${containingDir}/conf/* || fatal_error "Failed to persist SELinux type context on AppDynamics WebServer config files"
    restorecon -R -v ${containingDir}/sdk_lib/lib/* || fatal_error "Failed to persist SELinux type context on AppDynamics SDK modules directory"
    restorecon -R -v ${withSELinuxModulePath}/* || log_error "Failed to persist SELinux type context on AppDynamics Apache modules directory"

    selinuxPolicyFile="${selinuxPolicy}.te"
    selinuxPolicyModule="${selinuxPolicy}.mod"
    selinuxPolicyPackage="${selinuxPolicy}.pp"

    saveCwd=$CWD
    cd "${containingDir}/selinux"
    [ -f "${selinuxPolicyFile}" ] || fatal_error "Installer error: SELinux policy file ${selinuxPolicyFile} not found"

    log "Compiling AppDynamics SELinux policy module"
    checkmodule -M -m -o "$selinuxPolicyModule" "$selinuxPolicyFile" || fatal_error "Failed to compile SELinux policy module"
    log "Packaging AppDynamics SELinux policy"
    semodule_package -o "$selinuxPolicyPackage" -m "$selinuxPolicyModule" || fatal_error "Failed to package SELinux policy module"
    if semodule -l | grep $'^appdynamics_sdk[ \t]' >/dev/null; then
        log "Removing existing AppDynamics SELinux policy module"
        semodule -r "appdynamics_sdk" || fatal_error "Failed to remove existing SELinux policy module"
    fi
    semodule -i "$selinuxPolicyPackage" || fatal_error "Failed to load AppDynamics SELinux policy module"
    log "AppDynamics SELinux policy module loaded"

    cd "$saveCwd"
fi

restore_sebools_and_delete_file() {
    if [ -f "${seboolPreviousValuesFile}" ]; then
        cat "${seboolPreviousValuesFile}" | while read varEqualsValue; do
            if setsebool -P "${varEqualsValue}"; then
                log "Restored and persisted SELinux boolean ${varEqualsValue}"
            else
                log "Failed to restore and persist SELinux boolean ${varEqualsValue}"
            fi
        done
        rm "${seboolPreviousValuesFile}"
    fi
}
