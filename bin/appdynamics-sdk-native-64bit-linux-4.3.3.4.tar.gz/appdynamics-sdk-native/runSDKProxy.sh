#!/bin/sh
#
#
# Copyright 2014 AppDynamics.
# All rights reserved.
#
#
# Script to run AppDynamics Native SDK proxy
#

canonicalNameOfThisFile=`readlink -f "$0"`
containingDir=`dirname "$canonicalNameOfThisFile"`


run_proxy() 
{
    logsDirectory="${containingDir}/logs"
    proxyCommunicationDir="${containingDir}/logs/appd-sdk"
    if [ ! -z "$1" ]; then proxyCommunicationDir=$1; fi
    if [ ! -d $proxyCommunicationDir ]; then mkdir -m 755 -p $proxyCommunicationDir; fi
    echo "Using ${proxyCommunicationDir} as the proxy communication directory"
    proxyDirCheck=$(find "${proxyCommunicationDir}" -maxdepth 0 -perm -005 2>/dev/null)
    if [ -z "${proxyDirCheck}" ] ; then
        echo "[WARN] ProxyCommunicationDir '${proxyCommunicationDir}' is not readable/executable by all users, some apps may not be able to talk to proxy if not properly configured" >&2
    fi

    if [ ! -w "${proxyCommunicationDir}" ] || [ ! -r "${proxyCommunicationDir}" ] || [ ! -x "${proxyCommunicationDir}" ]; then
        echo "[Error] Current user does not have read/write/execute permissions on '${proxyCommunicationDir}'"
        exit 1
    fi

    proxyDirectory="${containingDir}/proxy"
    runProxyScript="${containingDir}/proxy/runProxy"

    "${runProxyScript}" "${proxyCommunicationDir}" "${logsDirectory}"
}

run_proxy "$@"
